package caozuo;

// 文件控制块类
class FCB {
    private String fileName; // 文件名
    private int startBlock;  // 起始盘块号
    private int fileSize;    // 文件大小
    private int fileId;      // 文件ID

    public FCB(String fileName, int startBlock, int fileSize) {
        this.fileName = fileName;
        this.startBlock = startBlock;
        this.fileSize = fileSize;
    }

    public int getFileId() {
        return fileId;
    }

    public void setFileId(int fileId) {
        this.fileId = fileId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getStartBlock() {
        return startBlock;
    }

    public void setStartBlock(int startBlock) {
        this.startBlock = startBlock;
    }

    public int getFileSize() {
        return fileSize;
    }
}