
package caozuo;

// 文件分配表类
class FileAllocationTable {
    private boolean[] allocationTable; // 分配表
    private int diskSize;              // 磁盘大小

    public FileAllocationTable(int diskSize) {
        this.diskSize = diskSize;
        allocationTable = new boolean[diskSize];
    }

    // 分配盘块
    public int allocateBlocks(int numberOfBlocks) {
        int startBlock = -1;
        int count = 0;
        for (int i = 0; i < diskSize + 1; i++) {
            if (i < diskSize && !allocationTable[i]) {
                if (count == 0) {
                    startBlock = i;
                }
                count++;
                if (count == numberOfBlocks) {
                    break;
                }
            } else {
                count = 0;
                startBlock = -1;
            }
        }

        if (startBlock != -1) {
            for (int i = startBlock; i < startBlock + numberOfBlocks; i++) {
                allocationTable[i] = true;
            }
        }

        return startBlock;
    }

    // 释放盘块
    public void freeBlocks(int startBlock, int numberOfBlocks) {
        for (int i = startBlock; i < startBlock + numberOfBlocks; i++) {
            allocationTable[i] = false;
        }
    }
}