package caozuo;

import java.util.*;

class MemoryManager {
    int totalMemory; // 总内存大小
    int freeMemory; // 空闲内存大小
    Map<Integer, Integer> memoryMap; // 进程ID与内存大小映射
    int[] memory; // 内存数组

    // 构造方法
    MemoryManager(int totalMemory) {
        this.totalMemory = totalMemory;
        this.memory = new int[totalMemory];
        this.freeMemory = totalMemory;
        this.memoryMap = new HashMap<>();
    }

    // 分配内存
    boolean allocateMemory(int pid, int size, int index) {
        if (index != -1) {
            for (int i = index; i < index + size; i++) {
                memory[i] = pid;
            }
            memoryMap.put(pid, size);
            freeMemory -= size;
            return true;
        } else {
            return false;
        }
    }

    // 查找可用内存块
    int find(int size) {
        int i, j, index = -1, minMemory = Integer.MAX_VALUE;
        for (i = 0; i < totalMemory; i++) {
            j = i;
            if (memory[i] == 0) {
                while (j < totalMemory && memory[j] == 0) {
                    j++;
                }
            }
            if (j - i < minMemory && j - i >= size) {
                index = i;
            }
            i = j;
        }
        return index;
    }

    // 释放内存
    void freeMemory(int pid) {
        if (memoryMap.containsKey(pid)) {
            int size = memoryMap.get(pid);
            for (int i = 0; i < totalMemory; i++) {
                if (memory[i] == pid) {
                    for (int j = i; j < i + size; j++) {
                        memory[j] = 0;
                    }
                    break;
                }
            }
            freeMemory += size;
            memoryMap.remove(pid);
        }
    }

    // 显示内存使用情况
    void showMemoryStatus() {
        System.out.println("总内存: " + totalMemory + ", 空闲内存: " + freeMemory);
        System.out.println("分区编号   分区始址    分区终址   空闲状态  作业号");
        int i = 0, j = i + 1, t = 0;
        while (i < totalMemory) {
            while (j < totalMemory && memory[j] == memory[j - 1]) {
                j++;
            }

            if (memory[i] == 0) {
                System.out.printf(" %6d     %6d      %6d       空闲\n", t, i, (j - 1));
            } else {
                System.out.printf(" %6d     %6d      %6d       占用  %6d\n", t, i, (j - 1), memory[i]);
            }
            t++;
            i = j;
            j++;
        }
    }
}
