package caozuo;

import java.util.Scanner;

public class OperatingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入磁盘大小:");
        int diskSize = scanner.nextInt();
        FileAllocationTable fat = new FileAllocationTable(diskSize);

        System.out.println("请输入内存大小:");
        int memorySize = scanner.nextInt();
        ProcessManager processManager = new ProcessManager(memorySize);

        while (true) {
            System.out.println("请输入命令 (1: 创建文件, 2: 删除文件, 3: 显示内存, 4: 创建进程, 5: 终止进程, 6: 显示进程, 7: 运行进程, 8: 退出):");
            int command = scanner.nextInt();

            switch (command) {
                case 1:
                    System.out.println("请输入文件名:");
                    String fileName = scanner.next();
                    System.out.println("请输入文件大小:");
                    int fileSize = scanner.nextInt();
                    int startBlock = fat.allocateBlocks(fileSize);
                    if (startBlock != -1) {
                        FCB newFile = new FCB(fileName, startBlock, fileSize);
                        System.out.println("文件已创建: 文件名 " + fileName + ", 起始块号 " + startBlock + ", 文件大小 " + fileSize);
                    } else {
                        System.out.println("磁盘空间不足，无法创建文件 " + fileName);
                    }
                    break;

                case 2:
                    System.out.println("请输入文件名:");
                    String deleteFileName = scanner.next();
                    System.out.println("请输入起始块号:");
                    int deleteStartBlock = scanner.nextInt();
                    System.out.println("请输入文件大小:");
                    int deleteFileSize = scanner.nextInt();
                    fat.freeBlocks(deleteStartBlock, deleteFileSize);
                    System.out.println("文件 " + deleteFileName + " 已删除.");
                    break;

                case 3:
                    processManager.memoryManager.showMemoryStatus();
                    break;

                case 4:
                    System.out.println("请输入进程ID:");
                    int pid = scanner.nextInt();
                    System.out.println("请输入进程所需内存大小:");
                    int processMemorySize = scanner.nextInt();
                    System.out.println("请输入进程估计运行时间:");
                    int estimatedTime = scanner.nextInt();
                    System.out.println("请输入进程I/O操作开始时间:");
                    int ioTimeStart = scanner.nextInt();
                    System.out.println("请输入进程I/O操作结束时间:");
                    int ioTimeEnd = scanner.nextInt();
                    processManager.createProcess(pid, processMemorySize, estimatedTime, ioTimeStart, ioTimeEnd);
                    break;

                case 5:
                    System.out.println("请输入进程ID:");
                    int terminatePid = scanner.nextInt();
                    processManager.killProcess(terminatePid);
                    break;

                case 6:
                    processManager.showAllProcesses();
                    break;

                case 7:
                    processManager.runProcess();
                    break;

                case 8:
                    System.out.println("退出系统.");
                    scanner.close();
                    return;

                default:
                    System.out.println("无效命令.");
                    break;
            }
        }
    }
}