package caozuo;

class PCB {
    int pid; // 进程ID
    int memorySize; // 内存大小
    int estimatedTime; // 估计运行时间
    int ioTimeStart; // I/O操作开始时间
    int ioTimeEnd; // I/O操作结束时间
    int memoryStart; // 内存起始地址
    int elapsedTime; // 已运行时间
    String status; // 进程状态

    // 构造方法
    PCB(int pid, int memorySize, int estimatedTime, int ioTimeStart, int ioTimeEnd, int memoryStart) {
        this.pid = pid;
        this.memorySize = memorySize;
        this.estimatedTime = estimatedTime;
        this.ioTimeStart = ioTimeStart;
        this.ioTimeEnd = ioTimeEnd;
        this.memoryStart = memoryStart;
        this.elapsedTime = 0; // 初始化已运行时间为0
        this.status = "就绪"; // 初始化状态为就绪
    }

    // 打印进程信息
    @Override
    public String toString() {
        return "PCB{" +
                "pid=" + pid +
                ", memorySize=" + memorySize +
                ", estimatedTime=" + estimatedTime +
                ", ioTimeStart=" + ioTimeStart +
                ", ioTimeEnd=" + ioTimeEnd +
                ", memoryStart=" + memoryStart +
                ", elapsedTime=" + elapsedTime +
                ", status='" + status + '\'' +
                '}';
    }
}
