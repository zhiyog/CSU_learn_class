package caozuo;

// 进程管理类
import java.util.*;

class ProcessManager {
    Map<Integer, PCB> processes; // 进程表
    MemoryManager memoryManager; // 内存管理器
    Queue<PCB> readyQueue; // 就绪队列
    Queue<PCB> blockedQueue; // 阻塞队列
    private final int TIME_QUANTUM = 5; // 时间片大小

    // 构造方法
    ProcessManager(int totalMemory) {
        this.processes = new HashMap<>();
        this.memoryManager = new MemoryManager(totalMemory);
        this.readyQueue = new LinkedList<>();
        this.blockedQueue = new LinkedList<>();
    }

    // 创建进程
    void createProcess(int pid, int memorySize, int estimatedTime, int ioTimeStart, int ioTimeEnd) {
        if (processes.containsKey(pid)) {
            System.out.println("进程ID " + pid + " 已存在.");
            return;
        }

        // 尝试分配内存
        int memoryStart = memoryManager.find(memorySize);
        if (memoryStart == -1) {
            System.out.println("内存不足，无法创建进程ID " + pid);
            return;
        }
        memoryManager.allocateMemory(pid, memorySize, memoryStart);
        // 创建进程并添加到进程表和就绪队列
        PCB newProcess = new PCB(pid, memorySize, estimatedTime, ioTimeStart, ioTimeEnd, memoryStart);
        processes.put(pid, newProcess);
        readyQueue.add(newProcess);

        System.out.println("进程已创建: " + newProcess);
    }

    // 终止进程
    void killProcess(int pid) {
        if (!processes.containsKey(pid)) {
            System.out.println("找不到进程ID " + pid);
            return;
        }

        PCB process = processes.get(pid);
        processes.remove(pid);
        readyQueue.remove(process);
        blockedQueue.remove(process);
        memoryManager.freeMemory(pid);

        System.out.println("进程ID " + pid + " 已终止.");
    }

    // 显示所有进程的状态信息
    void showAllProcesses() {
        System.out.println("所有进程:");
        for (PCB process : processes.values()) {
            System.out.println(process); // 打印进程信息
        }
    }

    // 将进程移到阻塞队列中并输出信息
    void blockProcess(PCB process) {
        blockedQueue.add(process);
        process.status = "阻塞";
        System.out.println("进程 " + process.pid + " 进入阻塞状态.");
    }

    // 模拟调度进程
    void runProcess() {
        int currentTime = 0;
        while (!readyQueue.isEmpty() || !blockedQueue.isEmpty()) {
            // 检查阻塞队列中的进程，是否完成I/O操作
            Queue<PCB> tempQueue = new LinkedList<>();
            while (!blockedQueue.isEmpty()) {
                PCB blockedProcess = blockedQueue.poll();
                if (currentTime >= blockedProcess.ioTimeEnd) {
                    blockedProcess.status = "就绪";
                    readyQueue.add(blockedProcess);
                    System.out.println("进程 " + blockedProcess.pid + " I/O操作完成，回到就绪队列.");
                } else {
                    tempQueue.add(blockedProcess);
                }
            }
            blockedQueue = tempQueue;

            if (!readyQueue.isEmpty()) {
                PCB currentProcess = readyQueue.poll(); // 获取就绪队列中的第一个进程
                currentProcess.status = "运行"; // 设置其状态为运行
                System.out.println("进程 " + currentProcess.pid + " 正在运行...");

                int timeSlice = Math.min(TIME_QUANTUM, currentProcess.estimatedTime - currentProcess.elapsedTime);

                for (int i = 0; i < timeSlice; i++) {
                    currentTime++;
                    currentProcess.elapsedTime++;

                    if (currentProcess.elapsedTime >= currentProcess.ioTimeStart && currentProcess.elapsedTime < currentProcess.ioTimeEnd) {
                        System.out.println("进程 " + currentProcess.pid + " 进行I/O操作...");
                        blockProcess(currentProcess); // 阻塞进程进行I/O操作
                        break; // 结束当前时间片
                    }

                    if (currentProcess.elapsedTime >= currentProcess.estimatedTime) {
                        currentProcess.status = "结束";
                        System.out.println("进程 " + currentProcess.pid + " 运行结束.");
                        killProcess(currentProcess.pid);
                        break;
                    }
                }

                if (currentProcess.status.equals("运行")) {
                    currentProcess.status = "就绪";
                    readyQueue.add(currentProcess);
                    System.out.println("进程 " + currentProcess.pid + " 本次时间片用完，未完成.");
                }
            }
        }
    }
}
